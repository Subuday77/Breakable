
public class Lamp extends Item implements Breakable {

	private int watt;

	Lamp(String name, int weight, int watt) {
		super(name, weight);
		this.watt = watt;
	}

	public int getWatt() {
		return watt;
	}

	public void setWatt(int watt) {
		this.watt = watt;
	}

	@Override
	public String toString() {
		if (watt == -99) {
			return getName() + " is broken\n";
		}
		return getName() + " weight=" + getWeight() + " watt=" + watt + "\n";
	}

	@Override
	public void breakIt() {
		// TODO Auto-generated method stub

	}

	public void broken(Item item) {
		setWeight(-99);
		setWatt(-99);
	}

}

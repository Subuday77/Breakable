
public class PaintBoard extends Item {
	
	private int width;
	private int height;
	
	PaintBoard(String name, int weight, int width, int height) {
		super(name, weight);
		this.width = width;
		this.height = height;
	}

	public int getWidth() {
		return width;
	}

	public void setWidth(int width) {
		this.width = width;
	}

	public int getHeight() {
		return height;
	}

	public void setHeight(int height) {
		this.height = height;
	}

	@Override
	public String toString() {
		return getName() +" weight="+ getWeight()+  " width=" + width + ", height=" + height + "\n";
	}

	@Override
	void broken(Item item) {
		// TODO Auto-generated method stub
		
	}
	
	
}

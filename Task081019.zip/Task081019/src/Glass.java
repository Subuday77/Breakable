
public class Glass extends Item implements Breakable {

	private int capacity;

	Glass(String name, int weight, int capacity) {
		super(name, weight);
		this.capacity = capacity;
	}

	public int getCapacity() {
		return capacity;
	}

	public void setCapacity(int capacity) {
		this.capacity = capacity;
	}

	@Override
	public String toString() {
		if (capacity == -99) {
			return getName() + " is broken\n";
		}
		return getName() + " weight=" + getWeight() + " capacity=" + capacity + "\n";
	}

	@Override
	public void breakIt() {
		// TODO Auto-generated method stub

	}

	public void broken(Item item) {
		setWeight(-99);
		setCapacity(-99);
	}

}

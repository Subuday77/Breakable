
public interface Breakable {
	
	public void breakIt();

}

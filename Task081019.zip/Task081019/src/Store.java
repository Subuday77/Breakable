
import java.util.ArrayList;



public class Store {

	public static void main(String[] args) {
		ArrayList<Item> items = new ArrayList<Item>();
		Item item1 = new Ball("Ball1", 100, "Green");
		Item item2 = new Ball("Ball2", 200, "Red");
		Item item3 = new Ball("Ball3", 300, "Blue");
		Item item4 = new PaintBoard("PaintBoard1",2000, 40, 40);
		Item item5 = new PaintBoard("PaintBoard2",2500, 60, 80);
		Item item6 = new Glass("Glass1",150,100);
		Item item7 = new Glass("Glass2",250,500);
		Item item8 = new Glass("Glass3",350,750);
		Item item9 = new Lamp("Lamp1",50,75);
		Item item10 = new Lamp("Lamp2",60,100);
		
		items.add(item1);
		items.add(item2);
		items.add(item3);
		items.add(item4);
		items.add(item5);
		items.add(item6);
		items.add(item7);
		items.add(item8);
		items.add(item9);
		items.add(item10);
		
		System.out.println(items);
		
		System.out.println();
		System.out.println("+++++++++++++++++++++++++\n");
		
		for (Item item:items) {
			if (item instanceof Breakable) {
				item.broken(item);
			}
		}
		
		System.out.println(items);
		
	}
	
	
}
